// netlify/functions/ai.js
// Proxy Claude API — rezoud CORS pèmanantman
// Kouri sou Netlify server — pa gen CORS blokaj

const CLAUDE_KEY = "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";

exports.handler = async (event) => {
  const CORS = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: CORS, body: '' };
  }

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers: CORS, body: JSON.stringify({ error: 'POST sèlman' }) };
  }

  try {
    const body = JSON.parse(event.body || '{}');
    
    const payload = {
      model: 'claude-sonnet-4-20250514',
      max_tokens: body.max_tokens || 2000,
      system: body.system || '',
      messages: body.messages || []
    };
    
    // Web search tool si mande
    if (body.tools) payload.tools = body.tools;

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': CLAUDE_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify(payload)
    });

    const data = await response.json();

    if (!response.ok) {
      return {
        statusCode: response.status,
        headers: CORS,
        body: JSON.stringify({ error: data.error?.message || 'API Error ' + response.status })
      };
    }

    return {
      statusCode: 200,
      headers: CORS,
      body: JSON.stringify(data)
    };

  } catch (err) {
    return {
      statusCode: 500,
      headers: CORS,
      body: JSON.stringify({ error: 'Serveur error: ' + err.message })
    };
  }
};
